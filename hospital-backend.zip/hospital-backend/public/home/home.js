// ========== SLIDER FUNCTIONALITY ==========
const slides = document.querySelectorAll('.hero-slide');
const dotsContainer = document.getElementById('dots');
let currentIndex = 0;

// Initialize hero slider dots
slides.forEach((_, idx) => {
  const dot = document.createElement('span');
  dot.addEventListener('click', () => showSlide(idx));
  dotsContainer.appendChild(dot);
});

const dots = dotsContainer.querySelectorAll('span');

function showSlide(index) {
  slides.forEach(slide => slide.classList.remove('active'));
  dots.forEach(dot => dot.classList.remove('active'));

  slides[index].classList.add('active');
  dots[index].classList.add('active');
  currentIndex = index;
}

function autoSlide() {
  currentIndex = (currentIndex + 1) % slides.length;
  showSlide(currentIndex);
}

// Initialize and auto-rotate hero slider
showSlide(0);
const heroInterval = setInterval(autoSlide, 5000);

// ========== NEWS SLIDER FUNCTIONALITY ==========
const newsSlides = document.querySelectorAll('.news-slide');
const newsDotsContainer = document.getElementById('newsDots');
let newsIndex = 0;

// Initialize news slider dots
newsSlides.forEach((_, i) => {
  const dot = document.createElement('span');
  dot.addEventListener('click', () => showNewsSlide(i));
  newsDotsContainer.appendChild(dot);
});

const newsDots = newsDotsContainer.querySelectorAll('span');

function showNewsSlide(index) {
  newsSlides.forEach(slide => slide.classList.remove('active'));
  newsDots.forEach(dot => dot.classList.remove('active'));

  newsSlides[index].classList.add('active');
  newsDots[index].classList.add('active');
  newsIndex = index;
}

function autoNewsSlide() {
  newsIndex = (newsIndex + 1) % newsSlides.length;
  showNewsSlide(newsIndex);
}

// Initialize and auto-rotate news slider
showNewsSlide(0);
const newsInterval = setInterval(autoNewsSlide, 6000);

// ========== LANGUAGE MANAGEMENT ==========
document.addEventListener("DOMContentLoaded", function() {
  const buttons = document.querySelectorAll(".lang-btn");
  const elements = document.querySelectorAll("[data-key]");
  const savedLang = localStorage.getItem("lang") || "ar";

  // Load translations from JSON
  function setLanguage(lang) {
    fetch("/lang.json")
        .then((res) => res.json())
        .then((data) => {
          elements.forEach((el) => {
            const key = el.getAttribute("data-key");
            if (data[lang] && data[lang][key]) {
              if (el.tagName === 'INPUT') {
                el.placeholder = data[lang][key];
              } else {
                el.textContent = data[lang][key];
              }
            }
          });

          // Update page direction
          document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
          document.documentElement.lang = lang;
          localStorage.setItem("lang", lang);
          updateButtonLabel(lang);
        })
        .catch(error => console.error("Translation error:", error));
  }

  // Update language button text
  function updateButtonLabel(lang) {
    buttons.forEach((btn) => {
      btn.innerHTML = `<i class="fas fa-globe"></i> ${lang === "ar" ? "English" : "عربي"}`;
    });
  }

  // Toggle language on button click
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const newLang = localStorage.getItem("lang") === "ar" ? "en" : "ar";
      setLanguage(newLang);
    });
  });

  // Initialize language
  setLanguage(savedLang);
});

// ========== NAVIGATION FUNCTIONS ==========
function goToPage(path) {
  window.location.href = path;
}

function goToPolicies() {
  window.location.href = "/policies/policies.html";
}

function showNewsDetail(newsId) {
  // This would be enhanced with actual API data in production
  const modal = document.getElementById('newsModal');
  const title = document.getElementById('modalTitle');
  const content = document.getElementById('modalContent');

  // Sample content - replace it with dynamic data
  if (newsId === 'news1') {
    title.textContent = 'إزالة حصوات ناجحة خلال موسم الحج';
    content.innerHTML = 'قام فريق طبي متخصص بإجراء عملية ناجحة لإزالة حصوات الكلى خلال موسم الحج 1446هـ...';
  } else {
    title.textContent = 'المواعيد الافتراضية';
    content.innerHTML = 'تم خدمة أكثر من 36 ألف مريض عبر المنصة الافتراضية...';
  }

  modal.style.display = 'block';
}

function closeModal() {
  document.getElementById('newsModal').style.display = 'none';
}

// Close modal when clicking outside
window.addEventListener('click', (event) => {
  const modal = document.getElementById('newsModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});

// ========== CLEANUP ON EXIT ==========
window.addEventListener('beforeunload', () => {
  clearInterval(heroInterval);
  clearInterval(newsInterval);
});