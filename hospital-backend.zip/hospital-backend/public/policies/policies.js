// ========== GLOBAL VARIABLES ==========
let currentLang = localStorage.getItem('lang') || 'ar';
let translations = {};
const policyData = {
  1: {
    title: { ar: "سياسة الخصوصية والبيانات", en: "Privacy and Data Policy" },
    desc: { ar: "ضمان سرية وأمان بيانات المرضى والموظفين", en: "Ensuring patient and staff data confidentiality" },
    category: { ar: "إدارية", en: "Administrative" },
    content: {
      ar: "<h3>نظرة عامة</h3><p>تهدف هذه السياسة إلى حماية المعلومات الشخصية...</p>",
      en: "<h3>Overview</h3><p>This policy aims to protect personal information...</p>"
    },
    pdf: "/docs/privacy.pdf",
    lastUpdated: "2024-06-15"
  },
  2: {
    title: { ar: "سياسة رعاية المرضى", en: "Patient Care Policy" },
    desc: { ar: "معايير تقديم الخدمات الطبية", en: "Medical service standards" },
    category: { ar: "طبية", en: "Medical" },
    content: {
      ar: "<h3>المعايير الطبية</h3><p>تتبع المستشفى أحدث البروتوكولات العالمية...</p>",
      en: "<h3>Medical Standards</h3><p>The hospital follows international protocols...</p>"
    },
    pdf: "/docs/patient_care.pdf",
    lastUpdated: "2024-05-20"
  }
};

// ========== DOM ELEMENTS ==========
const elements = {
  filterMenu: document.getElementById('filterMenu'),
  cardsContainer: document.querySelector('.cards-container'),
  policyModal: document.getElementById('policyModal'),
  modalTitle: document.getElementById('modalTitle'),
  modalContent: document.getElementById('modalContent'),
  modalCategory: document.getElementById('modalCategory'),
  modalDownload: document.getElementById('modalDownload'),
  modalDate: document.getElementById('modalDate'),
  langBtn: document.querySelector('.lang-btn span')
};

// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
  loadTranslations();
  setupEventListeners();
  renderPolicyCards();
  applyCurrentLanguage();
});

// ========== TRANSLATION SYSTEM ==========
async function loadTranslations() {
  try {
    const response = await fetch('/lang/policies.json');
    translations = await response.json();
    applyTranslations(currentLang);
  } catch (error) {
    console.error('Failed to load translations:', error);
  }
}

function applyTranslations(lang) {
  document.querySelectorAll('[data-key]').forEach(el => {
    const key = el.getAttribute('data-key');
    if (translations[lang]?.[key]) {
      el.textContent = translations[lang][key];
    }
  });

  // Update HTML direction and lang attribute
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;

  // Update language button text
  if (elements.langBtn) {
    elements.langBtn.textContent = lang === 'ar' ? 'English' : 'عربي';
  }
}

// ========== LANGUAGE TOGGLE ==========
function toggleLanguage() {
  currentLang = currentLang === 'ar' ? 'en' : 'ar';
  localStorage.setItem('lang', currentLang);
  applyTranslations(currentLang);
  renderPolicyCards(); // Re-render cards with new language
}

// ========== POLICY CARDS SYSTEM ==========
function renderPolicyCards() {
  elements.cardsContainer.innerHTML = '';

  Object.entries(policyData).forEach(([id, policy]) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.setAttribute('data-category', policy.category.ar);

    card.innerHTML = `
      <div class="card-icon">
        <i class="fas ${getCategoryIcon(policy.category.en)}"></i>
      </div>
      <div class="card-content">
        <h4>${policy.title[currentLang]}</h4>
        <p>${policy.desc[currentLang]}</p>
        <div class="card-footer">
          <span class="tag ${getCategoryClass(policy.category.en)}">
            ${policy.category[currentLang]}
          </span>
          <div class="card-actions">
            <button class="view-btn" onclick="openPolicyModal(${id})">
              <i class="fas fa-eye"></i> 
              <span data-key="view_details">${translations[currentLang]?.view_details || 'View'}</span>
            </button>
            <a href="${policy.pdf}" download class="download-btn">
              <i class="fas fa-download"></i> PDF
            </a>
          </div>
        </div>
      </div>
    `;

    elements.cardsContainer.appendChild(card);
  });
}

function getCategoryIcon(category) {
  const icons = {
    Administrative: 'fa-file-contract',
    Medical: 'fa-procedures',
    Security: 'fa-shield-alt'
  };
  return icons[category] || 'fa-file-alt';
}

function getCategoryClass(category) {
  return category.toLowerCase();
}

// ========== FILTERING SYSTEM ==========
function setupEventListeners() {
  // Filter menu
  elements.filterMenu?.addEventListener('click', (e) => {
    const li = e.target.closest('li');
    if (!li) return;

    // Update active filter
    document.querySelectorAll('#filterMenu li').forEach(item => {
      item.classList.remove('active');
    });
    li.classList.add('active');

    // Filter cards
    const filterValue = li.getAttribute('data-filter');
    filterCards(filterValue);
  });

  // Modal close
  document.querySelector('.close-btn')?.addEventListener('click', closeModal);
  window.addEventListener('click', (e) => {
    if (e.target === elements.policyModal) closeModal();
  });
}

function filterCards(filterValue) {
  document.querySelectorAll('.card').forEach(card => {
    const category = card.getAttribute('data-category');
    if (filterValue === 'all' || category === filterValue) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// ========== MODAL SYSTEM ==========
function openPolicyModal(policyId) {
  const policy = policyData[policyId];
  if (!policy) return;

  elements.modalTitle.textContent = policy.title[currentLang];
  elements.modalContent.innerHTML = policy.content[currentLang];
  elements.modalCategory.textContent = policy.category[currentLang];
  elements.modalCategory.className = `tag ${getCategoryClass(policy.category.en)}`;
  elements.modalDownload.href = policy.pdf;
  elements.modalDate.textContent = `${translations[currentLang]?.last_updated || 'Last updated'}: ${policy.lastUpdated}`;

  elements.policyModal.style.display = 'block';
}

function closeModal() {
  elements.policyModal.style.display = 'none';
}

// ========== UTILITY FUNCTIONS ==========
function applyCurrentLanguage() {
  if (!translations[currentLang]) {
    setTimeout(applyCurrentLanguage, 100);
    return;
  }
  applyTranslations(currentLang);
}

// Public API
window.toggleLanguage = toggleLanguage;
window.openPolicyModal = openPolicyModal;
window.closeModal = closeModal;